import { AgentConfig, AgentRunOptions } from "./types.js";
import { NekoraRuntime } from "../runtime/runtime.js";
import { ExecutionResult } from "../runtime/loop.js";
import { Tool } from "../tools/types.js";
import { ModelProvider } from "../providers/types.js";
import { GeminiProvider } from "../providers/gemini.provider.js";
import { OpenAIProvider } from "../providers/openai.provider.js";
import { ClaudeProvider } from "../providers/claude.provider.js";
import { GroqProvider } from "../providers/groq.provider.js";
import { SDKEventEmitter } from "../events/event-emitter.js";
import { SDKEvent } from "../events/types.js";
import { PluginManager } from "../plugins/plugin-manager.js";
import { NekoraPlugin } from "../plugins/types.js";
import { ToolPermissionManager } from "../tools/permissions.js";
import { PersonalityProfile } from "../personality/types.js";
import { PersonalityCompiler } from "../personality/compiler.js";
import { NekoCognitiveMemory } from "../memory/cognitive/cognitive.memory.js";
import { BehaviorLearner } from "../behavior/learner.js";
import { BehaviorProfile } from "../behavior/types.js";
import { AgentSandbox } from "../sandbox/simulator.js";
import { SimulationReport } from "../sandbox/types.js";
import { MemoryAdapter } from "../memory/types.js";
import { SessionStore } from "../session/types.js";
import { GuardrailPipeline } from "../guardrails/pipeline.js";
import { HandoffManager } from "../handoff/handoff.manager.js";

/**
 * Resolve explicit or default ModelProvider based on environment configuration or provider instance.
 */
export function resolveDefaultProvider(modelInput?: ModelProvider | string): ModelProvider {
  if (typeof modelInput === "object" && modelInput !== null && "generate" in modelInput) {
    return modelInput;
  }

  const modelStr = typeof modelInput === "string" ? modelInput.toLowerCase().trim() : "";

  if (modelStr.includes("gemini") || (!modelInput && process.env.GEMINI_API_KEY)) {
    return new GeminiProvider({
      apiKey: process.env.GEMINI_API_KEY || "",
      model: "gemini-2.0-flash",
    });
  }

  if (modelStr.includes("openai") || modelStr.includes("gpt") || (!modelInput && process.env.OPENAI_API_KEY)) {
    return new OpenAIProvider({
      apiKey: process.env.OPENAI_API_KEY || "",
      model: "gpt-4o-mini",
    });
  }

  if (modelStr.includes("claude") || modelStr.includes("anthropic") || (!modelInput && process.env.ANTHROPIC_API_KEY)) {
    return new ClaudeProvider({
      apiKey: process.env.ANTHROPIC_API_KEY || "",
      model: "claude-3-5-sonnet-20241022",
    });
  }

  if (modelStr.includes("groq") || (!modelInput && process.env.GROQ_API_KEY)) {
    return new GroqProvider({
      apiKey: process.env.GROQ_API_KEY || "",
      model: "llama-3.3-70b-versatile",
    });
  }

  throw new Error(
    "No ModelProvider specified and no default API keys found. " +
      "Please pass a model instance (e.g., new OpenAIProvider(...)) or set GEMINI_API_KEY, OPENAI_API_KEY, ANTHROPIC_API_KEY, or GROQ_API_KEY in process.env."
  );
}

/**
 * Agent
 * 
 * Production-grade developer API for Nekora AI agents with Cognitive Memory,
 * Personality Profiles, Behavior Evolution, and Sandbox Simulation.
 */
export class Agent {
  readonly id: string;
  readonly name: string;
  readonly personality?: PersonalityProfile;
  readonly memory: NekoCognitiveMemory;
  readonly memoryAdapter: MemoryAdapter;
  readonly behavior: { profile: () => BehaviorProfile };

  private baseInstructions: string;
  private instructions: string;
  private model: ModelProvider;
  private tools: Map<string, Tool> = new Map();
  private eventEmitter: SDKEventEmitter;
  private pluginManager: PluginManager;
  private permissionManager: ToolPermissionManager;
  private guardrails?: GuardrailPipeline;
  private sessionStore?: SessionStore;
  private handoffManager?: HandoffManager;
  private behaviorLearner: BehaviorLearner;
  private runtime: NekoraRuntime;

  constructor(config: AgentConfig) {
    this.id = config.id || `agent_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`;
    this.name = config.name;
    this.baseInstructions = config.instructions;
    this.personality = config.personality;
    this.guardrails = config.guardrails;
    this.sessionStore = config.sessionStore;
    this.handoffManager = config.handoffManager;

    // Compile base instructions with personality prompt directives
    const personalityPrompt = PersonalityCompiler.compile(this.name, this.personality);
    this.instructions = `${this.baseInstructions}${personalityPrompt ? `\n${personalityPrompt}` : ""}`;

    this.model = resolveDefaultProvider(config.model);

    // Initialize Memory Adapter & Cognitive Memory
    if (config.memory instanceof NekoCognitiveMemory) {
      this.memory = config.memory;
      this.memoryAdapter = config.memory;
    } else if (config.memory) {
      this.memoryAdapter = config.memory;
      this.memory = new NekoCognitiveMemory();
    } else {
      this.memory = new NekoCognitiveMemory();
      this.memoryAdapter = this.memory;
    }

    // Initialize Behavior Evolution Learner
    this.behaviorLearner = new BehaviorLearner(this.memory);
    this.behavior = {
      profile: () => this.behaviorLearner.getProfile(),
    };

    this.eventEmitter = new SDKEventEmitter();
    this.pluginManager = new PluginManager();
    this.permissionManager = new ToolPermissionManager(config.permissions || ["*"]);

    if (config.tools) {
      for (const t of config.tools) {
        this.tools.set(t.name, t);
      }
    }

    if (config.plugins) {
      for (const p of config.plugins) {
        this.use(p);
      }
    }

    this.runtime = new NekoraRuntime({
      agentId: this.id,
      instructions: this.instructions,
      model: this.model,
      tools: Array.from(this.tools.values()),
      memory: this.memoryAdapter,
      sessionStore: this.sessionStore,
      guardrails: this.guardrails,
      permissionManager: this.permissionManager,
      handoffManager: this.handoffManager,
      eventEmitter: this.eventEmitter,
      pluginManager: this.pluginManager,
      maxRetries: config.maxRetries ?? 2,
      timeoutMs: config.timeoutMs,
    });
  }

  /**
   * Register a plugin to extend agent lifecycle hooks.
   */
  use(plugin: NekoraPlugin): this {
    this.pluginManager.use(plugin);
    return this;
  }

  /**
   * Dynamically switch model provider at runtime.
   */
  useModel(model: ModelProvider | string): this {
    this.model = resolveDefaultProvider(model);
    this.refreshRuntime();
    return this;
  }

  /**
   * Dynamically register a tool at runtime.
   */
  registerTool(tool: Tool): this {
    this.tools.set(tool.name, tool);
    this.refreshRuntime();
    return this;
  }

  /**
   * Update base system prompt instructions.
   */
  setInstructions(instructions: string): this {
    this.baseInstructions = instructions;
    const personalityPrompt = PersonalityCompiler.compile(this.name, this.personality);
    this.instructions = `${this.baseInstructions}${personalityPrompt ? `\n${personalityPrompt}` : ""}`;
    this.refreshRuntime();
    return this;
  }

  private refreshRuntime(): void {
    this.runtime = new NekoraRuntime({
      agentId: this.id,
      instructions: this.instructions,
      model: this.model,
      tools: Array.from(this.tools.values()),
      memory: this.memoryAdapter,
      sessionStore: this.sessionStore,
      guardrails: this.guardrails,
      handoffManager: this.handoffManager,
      eventEmitter: this.eventEmitter,
      pluginManager: this.pluginManager,
      permissionManager: this.permissionManager,
    });
  }

  /**
   * Run the agent on a user query with Cognitive Memory & Behavior Evolution.
   */
  async run<T = string>(
    input: string,
    options: AgentRunOptions = {}
  ): Promise<ExecutionResult<T>> {
    // 1. Observe & learn user behavior patterns into LTM
    this.behaviorLearner.observeTurn(input, options.sessionId);

    // 2. Retrieve relevant Cognitive LTM context and inject into runtime instructions
    const memoryContextBlock = this.memory.retrieveContextBlock(input);
    let activeInstructions = this.instructions;
    if (memoryContextBlock) {
      activeInstructions = `${this.instructions}\n\n${memoryContextBlock}`;
    }

    // Re-instantiate scoped runtime with active instructions
    const scopedRuntime = new NekoraRuntime({
      agentId: this.id,
      instructions: activeInstructions,
      model: this.model,
      tools: Array.from(this.tools.values()),
      memory: this.memoryAdapter,
      sessionStore: this.sessionStore,
      guardrails: this.guardrails,
      handoffManager: this.handoffManager,
      eventEmitter: this.eventEmitter,
      pluginManager: this.pluginManager,
      permissionManager: this.permissionManager,
    });

    return scopedRuntime.execute<T>(input, options);
  }

  /**
   * Stream real-time events and generated tokens as an AsyncIterable.
   */
  async *stream(
    input: string,
    options: AgentRunOptions = {}
  ): AsyncIterable<SDKEvent> {
    const iterable = this.eventEmitter.toAsyncIterable();
    this.run(input, options).catch(() => {});
    yield* iterable;
  }

  /**
   * Safe Agent Sandbox / Simulation Mode: Preview planned tool calls, risk levels, and timeline without executing side-effects.
   */
  async simulate(input: string): Promise<SimulationReport> {
    return AgentSandbox.simulate(
      input,
      Array.from(this.tools.values()),
      this.instructions
    );
  }

  getEventEmitter(): SDKEventEmitter {
    return this.eventEmitter;
  }

  getModel(): ModelProvider {
    return this.model;
  }
}
