import { z } from "zod";
import { ToolDefinition } from "../providers/types.js";

export interface ToolExecutionContext {
  runId?: string;
  sessionId?: string;
  agentId?: string;
  signal?: AbortSignal;
  metadata?: Record<string, unknown>;
}

export interface ToolConfig<TInput = any, TOutput = any> {
  name: string;
  description: string;
  schema?: z.ZodType<TInput> | Record<string, unknown>;
  permissions?: string[];
  requireApproval?: boolean;
  execute: (args: TInput, context?: ToolExecutionContext) => Promise<TOutput>;
}

export interface Tool<TInput = any, TOutput = any> {
  name: string;
  description: string;
  parameters: Record<string, unknown>;
  permissions?: string[];
  requireApproval?: boolean;
  schema?: z.ZodType<TInput> | Record<string, unknown>;
  execute: (args: TInput, context?: ToolExecutionContext) => Promise<TOutput>;
  toDefinition(): ToolDefinition;
}

export class ToolError extends Error {
  public readonly code: string;

  constructor(
    message: string,
    public readonly toolName: string,
    code: string = "TOOL_ERROR",
    public readonly cause?: unknown
  ) {
    super(`Tool '${toolName}' error: ${message}`);
    this.name = "ToolError";
    this.code = code;
    if (cause && cause instanceof Error && cause.stack) {
      this.stack = `${this.stack}\nCaused by: ${cause.stack}`;
    }
  }
}

export class ToolValidationError extends ToolError {
  constructor(toolName: string, message: string, cause?: unknown) {
    super(`Validation failed: ${message}`, toolName, "TOOL_VALIDATION_FAILED", cause);
    this.name = "ToolValidationError";
  }
}

export class ToolPermissionError extends ToolError {
  constructor(toolName: string, public readonly missingPermission: string) {
    super(`Missing required permission '${missingPermission}'`, toolName, "TOOL_PERMISSION_DENIED");
    this.name = "ToolPermissionError";
  }
}

export class ToolApprovalRequiredError extends ToolError {
  constructor(toolName: string, public readonly args: unknown) {
    super(`Tool execution requires human approval before proceeding`, toolName, "TOOL_APPROVAL_REQUIRED");
    this.name = "ToolApprovalRequiredError";
  }
}

export class ToolExecutionError extends ToolError {
  constructor(toolName: string, message: string, cause?: unknown) {
    super(message, toolName, "TOOL_EXECUTION_FAILED", cause);
    this.name = "ToolExecutionError";
  }
}
