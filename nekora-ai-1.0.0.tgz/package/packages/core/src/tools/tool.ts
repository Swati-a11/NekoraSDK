import { z } from "zod";
import { ToolDefinition } from "../providers/types.js";
import {
  Tool,
  ToolConfig,
  ToolExecutionContext,
  ToolExecutionError,
  ToolValidationError,
} from "./types.js";

function zodToJsonSchema(schema: unknown): Record<string, unknown> {
  if (!schema) {
    return { type: "object", properties: {} };
  }

  // If it's already a plain object (JSON schema style)
  if (typeof schema === "object" && !("_def" in schema)) {
    return schema as Record<string, unknown>;
  }

  // Handle Zod Schema conversion
  if (typeof schema === "object" && schema !== null && "_def" in schema) {
    const zodSchema = schema as z.ZodType;
    const def = (zodSchema as any)._def;

    if (def.typeName === "ZodObject") {
      const shape = def.shape();
      const properties: Record<string, unknown> = {};
      const required: string[] = [];

      for (const [key, value] of Object.entries(shape)) {
        const valDef = (value as any)?._def;
        const typeName = valDef?.typeName;
        const description = (value as any)?.description;

        let propType = "string";
        if (typeName === "ZodNumber") propType = "number";
        else if (typeName === "ZodBoolean") propType = "boolean";
        else if (typeName === "ZodArray") propType = "array";
        else if (typeName === "ZodObject") propType = "object";
        else if (typeName === "ZodEnum") propType = "string";

        properties[key] = {
          type: propType,
          ...(description ? { description } : {}),
        };

        if (typeName !== "ZodOptional" && typeName !== "ZodDefault") {
          required.push(key);
        }
      }

      return {
        type: "object",
        properties,
        ...(required.length > 0 ? { required } : {}),
      };
    }
  }

  return { type: "object", properties: {} };
}

export function tool<TInput = any, TOutput = any>(
  config: ToolConfig<TInput, TOutput>
): Tool<TInput, TOutput> {
  const parameters = zodToJsonSchema(config.schema);

  return {
    name: config.name,
    description: config.description,
    parameters,
    permissions: config.permissions || [],
    requireApproval: config.requireApproval ?? false,
    schema: config.schema,

    toDefinition(): ToolDefinition {
      return {
        name: config.name,
        description: config.description,
        parameters,
      };
    },

    async execute(args: TInput, context?: ToolExecutionContext): Promise<TOutput> {
      let validatedArgs = args;

      if (config.schema) {
        if (typeof config.schema === "object" && "parse" in config.schema && typeof (config.schema as any).parse === "function") {
          try {
            validatedArgs = (config.schema as z.ZodType<TInput>).parse(args);
          } catch (err) {
            const msg = err instanceof Error ? err.message : String(err);
            throw new ToolValidationError(config.name, msg);
          }
        }
      }

      try {
        return await config.execute(validatedArgs, context);
      } catch (err) {
        if (err instanceof ToolValidationError) throw err;
        const msg = err instanceof Error ? err.message : String(err);
        throw new ToolExecutionError(config.name, msg, err);
      }
    },
  };
}
