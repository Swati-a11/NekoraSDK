export type Role = "system" | "user" | "assistant" | "tool";

export interface ToolCall {
  id: string;
  name: string;
  arguments: Record<string, unknown>;
}

export interface Message {
  role: Role;
  content: string;
  name?: string;
  toolCallId?: string;
  toolCalls?: ToolCall[];
}

export interface TokenUsage {
  promptTokens: number;
  completionTokens: number;
  totalTokens: number;
}

export interface ProviderConfig {
  apiKey?: string;
  baseUrl?: string;
  model: string;
  temperature?: number;
  maxTokens?: number;
  topP?: number;
  headers?: Record<string, string>;
  timeoutMs?: number;
}

export interface ModelResponseChunk {
  deltaText?: string;
  deltaToolCall?: Partial<ToolCall>;
  finishReason?: "stop" | "tool_calls" | "length" | "content_filter";
  usage?: TokenUsage;
}

export interface ModelResponse {
  text: string;
  toolCalls?: ToolCall[];
  finishReason: "stop" | "tool_calls" | "length" | "content_filter";
  usage?: TokenUsage;
  rawResponse?: unknown;
}

export interface ToolDefinition {
  name: string;
  description: string;
  parameters: Record<string, unknown>;
}

export interface GenerateOptions {
  tools?: ToolDefinition[];
  temperature?: number;
  maxTokens?: number;
  signal?: AbortSignal;
}

export interface ModelProvider {
  readonly id: string;
  readonly modelName: string;

  generate(messages: Message[], options?: GenerateOptions): Promise<ModelResponse>;
  generateStream(messages: Message[], options?: GenerateOptions): AsyncIterable<ModelResponseChunk>;
}

export class ProviderError extends Error {
  public readonly code: string;

  constructor(
    message: string,
    public readonly provider: string,
    public readonly statusCode?: number,
    public readonly isRetryable: boolean = false,
    public readonly cause?: unknown,
    code: string = "PROVIDER_ERROR"
  ) {
    super(`Provider '${provider}' error: ${message}`);
    this.name = "ProviderError";
    this.code = code;
    if (cause && cause instanceof Error && cause.stack) {
      this.stack = `${this.stack}\nCaused by: ${cause.stack}`;
    }
  }
}

export class AuthenticationError extends ProviderError {
  constructor(provider: string, message = "Invalid API key or unauthorized request.") {
    super(message, provider, 401, false, undefined, "AUTHENTICATION_FAILED");
    this.name = "AuthenticationError";
  }
}

export class RateLimitError extends ProviderError {
  constructor(provider: string, message = "Rate limit exceeded (HTTP 429).") {
    super(message, provider, 429, true, undefined, "RATE_LIMIT_EXCEEDED");
    this.name = "RateLimitError";
  }
}

export class ProviderServerError extends ProviderError {
  constructor(provider: string, statusCode: number, message = "Provider internal server error.") {
    super(message, provider, statusCode, true, undefined, "PROVIDER_SERVER_ERROR");
    this.name = "ProviderServerError";
  }
}
