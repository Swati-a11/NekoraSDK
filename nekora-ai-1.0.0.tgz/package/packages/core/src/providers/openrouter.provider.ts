import { OpenAIProvider } from "./openai.provider.js";
import { ProviderConfig } from "./types.js";

export class OpenRouterProvider extends OpenAIProvider {
  override readonly id = "openrouter";

  constructor(config: ProviderConfig) {
    super({
      ...config,
      apiKey: config.apiKey || process.env.OPENROUTER_API_KEY,
      baseUrl: config.baseUrl || "https://openrouter.ai/api/v1",
      headers: {
        "HTTP-Referer": "https://nekora.ai",
        "X-Title": "Nekora AI SDK",
        ...config.headers,
      },
    });
  }
}
