import {
  ModelProvider,
  Message,
  GenerateOptions,
  ModelResponse,
  ModelResponseChunk,
  ProviderError,
} from "./types.js";

export interface FallbackProviderOptions {
  onFallback?: (primary: string, fallback: string, reason: string) => void;
}

export class FallbackProvider implements ModelProvider {
  readonly id = "fallback";
  readonly modelName: string;
  private providers: ModelProvider[];
  private onFallback?: (primary: string, fallback: string, reason: string) => void;

  constructor(providers: ModelProvider[], options?: FallbackProviderOptions) {
    if (!providers || providers.length === 0) {
      throw new Error("FallbackProvider requires at least one provider.");
    }
    this.providers = providers;
    this.modelName = `fallback-[${providers.map((p) => p.modelName).join(",")}]`;
    this.onFallback = options?.onFallback;
  }

  async generate(messages: Message[], options?: GenerateOptions): Promise<ModelResponse> {
    const errors: Array<{ provider: string; error: unknown }> = [];
    const primaryProvider = this.providers[0]!;

    for (let i = 0; i < this.providers.length; i++) {
      const provider = this.providers[i]!;
      try {
        const response = await provider.generate(messages, options);
        // If we succeeded on a fallback provider (i > 0), notify callback
        if (i > 0 && this.onFallback) {
          const reason = errors[i - 1]?.error instanceof Error ? (errors[i - 1]?.error as Error).message : "Primary failed";
          this.onFallback(primaryProvider.id, provider.id, reason);
        }
        return response;
      } catch (err) {
        errors.push({ provider: provider.id, error: err });
        // Continue trying next provider in fallback chain
      }
    }

    throw new ProviderError(
      `All fallback providers failed: ${errors.map((e) => `${e.provider} (${(e.error as Error).message})`).join("; ")}`,
      "fallback",
      undefined,
      false
    );
  }

  async *generateStream(messages: Message[], options?: GenerateOptions): AsyncIterable<ModelResponseChunk> {
    for (let i = 0; i < this.providers.length; i++) {
      const provider = this.providers[i]!;
      try {
        for await (const chunk of provider.generateStream(messages, options)) {
          yield chunk;
        }
        return;
      } catch {
        // Continue trying next fallback provider
      }
    }
    throw new ProviderError("All fallback providers failed stream generation", "fallback");
  }
}
