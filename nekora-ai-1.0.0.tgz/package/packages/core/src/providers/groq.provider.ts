import { OpenAIProvider } from "./openai.provider.js";
import { ProviderConfig } from "./types.js";

export class GroqProvider extends OpenAIProvider {
  override readonly id = "groq";

  constructor(config: ProviderConfig) {
    super({
      ...config,
      apiKey: config.apiKey || process.env.GROQ_API_KEY,
      baseUrl: config.baseUrl || "https://api.groq.com/openai/v1",
    });
  }
}
