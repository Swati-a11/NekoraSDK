import { Message } from "../providers/types.js";
import { z } from "zod";

export type ExecutionState =
  | "idle"
  | "running"
  | "waiting_tool"
  | "waiting_approval"
  | "handoff"
  | "completed"
  | "failed"
  | "cancelled";

export interface ExecutionOptions {
  maxIterations?: number;
  timeoutMs?: number;
  signal?: AbortSignal;
  sessionId?: string;
  userId?: string;
  outputSchema?: z.ZodType<any> | Record<string, unknown>;
  requireApprovalForTools?: boolean;
  metadata?: Record<string, unknown>;
}

export class ExecutionContext {
  readonly runId: string;
  readonly agentId: string;
  readonly sessionId: string;
  readonly userId?: string;
  readonly signal?: AbortSignal;
  state: ExecutionState = "idle";
  stepCount: number = 0;
  messages: Message[] = [];
  metadata: Record<string, unknown> = {};
  readonly startTime: number;

  constructor(config: {
    runId?: string;
    agentId: string;
    sessionId?: string;
    userId?: string;
    signal?: AbortSignal;
    metadata?: Record<string, unknown>;
  }) {
    this.runId = config.runId || `run_${Date.now()}_${Math.random().toString(36).substr(2, 8)}`;
    this.agentId = config.agentId;
    this.sessionId = config.sessionId || `sess_${Date.now()}_${Math.random().toString(36).substr(2, 8)}`;
    this.userId = config.userId;
    this.signal = config.signal;
    this.metadata = config.metadata || {};
    this.startTime = Date.now();
  }

  checkCancellation(): void {
    if (this.signal?.aborted) {
      this.state = "cancelled";
      throw new Error(`Execution '${this.runId}' was cancelled.`);
    }
  }
}
