export type SDKEvent =
  | { type: "run.started"; runId: string; agentId: string; timestamp: number; input: unknown }
  | { type: "agent_started"; agentId: string; timestamp: number }
  | { type: "model.started"; runId: string; model: string; timestamp: number; messageCount: number }
  | { type: "token.generated"; delta: string; timestamp?: number }
  | { type: "text_stream"; delta: string }
  | { type: "tool.started"; toolName: string; input: unknown; runId?: string; timestamp: number }
  | { type: "tool_started"; toolName: string; input: unknown }
  | { type: "tool.completed"; toolName: string; output: unknown; runId?: string; timestamp: number }
  | { type: "tool_completed"; toolName: string; output: unknown }
  | { type: "handoff.started"; fromAgentId: string; toAgentId: string; reason: string; runId?: string; timestamp: number }
  | { type: "handoff_started"; fromAgentId: string; toAgentId: string; reason: string }
  | { type: "guardrail.failed"; guardrailName: string; stage: string; reason: string; runId?: string; timestamp: number }
  | { type: "guardrail_triggered"; guardrailName: string; stage: string; action: string }
  | { type: "approval.required"; toolName: string; args: unknown; runId?: string; timestamp: number }
  | { type: "provider.fallback"; primary: string; fallback: string; reason: string; timestamp: number }
  | { type: "retry"; attempt: number; error: string }
  | { type: "run.completed"; runId: string; result: unknown; timestamp: number }
  | { type: "run_completed"; result: unknown }
  | { type: "run.failed"; runId: string; error: Error; timestamp: number }
  | { type: "run_failed"; error: Error };

export type SDKEventType = SDKEvent["type"];
