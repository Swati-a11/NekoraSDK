import { SDKEvent, SDKEventType } from "./types.js";

type Listener<T extends SDKEvent> = (data: T) => void;

export class SDKEventEmitter {
  private listeners: Map<string, Array<Listener<any>>> = new Map();

  on<K extends SDKEventType>(
    eventType: K,
    listener: (data: Extract<SDKEvent, { type: K }>) => void
  ): () => void {
    const list = this.listeners.get(eventType) || [];
    list.push(listener);
    this.listeners.set(eventType, list);

    return () => {
      const updated = (this.listeners.get(eventType) || []).filter((l) => l !== listener);
      this.listeners.set(eventType, updated);
    };
  }

  emit(event: SDKEvent): void {
    const list = this.listeners.get(event.type) || [];
    for (const listener of list) {
      try {
        listener(event);
      } catch (err) {
        console.error(`Error in event listener for ${event.type}:`, err);
      }
    }
  }

  async *toAsyncIterable(): AsyncIterable<SDKEvent> {
    const queue: SDKEvent[] = [];
    let resolver: (() => void) | null = null;
    let done = false;

    const unsubs: Array<() => void> = [];

    const push = (evt: SDKEvent) => {
      queue.push(evt);
      if (resolver) {
        resolver();
        resolver = null;
      }
      if (
        evt.type === "run.completed" ||
        evt.type === "run_completed" ||
        evt.type === "run.failed" ||
        evt.type === "run_failed"
      ) {
        done = true;
      }
    };

    const types: SDKEventType[] = [
      "run.started",
      "agent_started",
      "model.started",
      "token.generated",
      "text_stream",
      "tool.started",
      "tool_started",
      "tool.completed",
      "tool_completed",
      "handoff.started",
      "handoff_started",
      "guardrail.failed",
      "guardrail_triggered",
      "approval.required",
      "provider.fallback",
      "retry",
      "run.completed",
      "run_completed",
      "run.failed",
      "run_failed",
    ];

    for (const t of types) {
      unsubs.push(this.on(t, push));
    }

    try {
      while (!done || queue.length > 0) {
        if (queue.length === 0) {
          await new Promise<void>((r) => {
            resolver = r;
          });
        }
        while (queue.length > 0) {
          yield queue.shift()!;
        }
      }
    } finally {
      for (const unsub of unsubs) unsub();
    }
  }
}
