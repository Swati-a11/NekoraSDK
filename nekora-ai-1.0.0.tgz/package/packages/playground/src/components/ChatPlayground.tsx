import React, { useState } from "react";
import { Send, Cpu, Wrench, History, Activity, ShieldCheck } from "lucide-react";
import { TraceStepNode } from "./TraceViewer";

interface ChatMessage {
  id: string;
  sender: "user" | "agent";
  text: string;
  toolsUsed?: string[];
  streaming?: boolean;
}

interface ChatPlaygroundProps {
  onTraceUpdate?: (steps: TraceStepNode[]) => void;
}

export const ChatPlayground: React.FC<ChatPlaygroundProps> = ({ onTraceUpdate }) => {
  const [input, setInput] = useState("");
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: "1",
      sender: "agent",
      text: "Hello! I am your Nekora AI Agent powered by custom provider, guardrails, and memory modules. How can I help you?",
    },
  ]);
  const [tools, setTools] = useState<string[]>(["weather_fetcher", "database_query"]);
  const [memoryHistory, setMemoryHistory] = useState<Array<{ role: string; content: string }>>([
    { role: "assistant", content: "Hello! I am your Nekora AI Agent..." },
  ]);

  const handleSend = () => {
    if (!input.trim()) return;

    const userMsg: ChatMessage = {
      id: String(Date.now()),
      sender: "user",
      text: input,
    };

    setMessages((prev) => [...prev, userMsg]);
    setMemoryHistory((prev) => [...prev, { role: "user", content: input }]);

    const currentInput = input;
    setInput("");

    // Simulated streaming response
    setTimeout(() => {
      const agentMsgId = String(Date.now() + 1);
      setMessages((prev) => [
        ...prev,
        {
          id: agentMsgId,
          sender: "agent",
          text: `Executing agent response for: "${currentInput}"...`,
          toolsUsed: ["weather_fetcher"],
        },
      ]);
      setMemoryHistory((prev) => [...prev, { role: "assistant", content: `Executing agent response for: "${currentInput}"...` }]);

      if (onTraceUpdate) {
        onTraceUpdate([
          { id: "1", type: "userInput", label: "User Input", subText: `"${currentInput}"` },
          { id: "2", type: "modelCall", label: "Model Call: OpenAI", subText: "Latency: 210ms | Tokens: 34" },
          { id: "3", type: "toolExecution", label: "Tool Execution", subText: "weather_fetcher({ query: '...' })" },
          { id: "4", type: "finalOutput", label: "Final Response", subText: "Generated in 420ms" },
        ]);
      }
    }, 600);
  };

  return (
    <div style={{ display: "grid", gridTemplateColumns: "1fr 340px", gap: "16px", height: "100%" }}>
      {/* Left Chat Column */}
      <div style={{ display: "flex", flexDirection: "column", background: "#0f172a", borderRadius: "12px", border: "1px solid #1e293b", padding: "16px" }}>
        <div style={{ display: "flex", alignItems: "center", gap: "8px", paddingBottom: "12px", borderBottom: "1px solid #1e293b", marginBottom: "12px" }}>
          <Cpu size={20} color="#38bdf8" />
          <h2 style={{ fontSize: "16px", margin: 0, fontWeight: 600 }}>Nekora Agent Session</h2>
        </div>

        {/* Message Stream */}
        <div style={{ flex: 1, overflowY: "auto", display: "flex", flexDirection: "column", gap: "12px", paddingRight: "8px" }}>
          {messages.map((m) => (
            <div
              key={m.id}
              style={{
                alignSelf: m.sender === "user" ? "flex-end" : "flex-start",
                maxWidth: "80%",
                background: m.sender === "user" ? "#2563eb" : "#1e293b",
                color: "#f8fafc",
                padding: "12px 16px",
                borderRadius: "12px",
                fontSize: "14px",
                lineHeight: "1.5",
              }}
            >
              <div>{m.text}</div>
              {m.toolsUsed && m.toolsUsed.length > 0 && (
                <div style={{ marginTop: "8px", display: "flex", gap: "6px", alignItems: "center" }}>
                  <Wrench size={12} color="#f97316" />
                  <span style={{ fontSize: "11px", color: "#fdba74" }}>
                    Tools used: {m.toolsUsed.join(", ")}
                  </span>
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Input Bar */}
        <div style={{ display: "flex", gap: "8px", marginTop: "12px" }}>
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && handleSend()}
            placeholder="Type your message to Nekora Agent..."
            style={{
              flex: 1,
              background: "#1e293b",
              border: "1px solid #334155",
              borderRadius: "8px",
              padding: "12px 16px",
              color: "#f8fafc",
              fontSize: "14px",
              outline: "none",
            }}
          />
          <button
            onClick={handleSend}
            style={{
              background: "#3b82f6",
              color: "#ffffff",
              border: "none",
              borderRadius: "8px",
              padding: "12px 18px",
              cursor: "pointer",
              display: "flex",
              alignItems: "center",
              gap: "6px",
              fontWeight: 600,
            }}
          >
            <Send size={16} /> Send
          </button>
        </div>
      </div>

      {/* Right Sidebar: Tools & Memory Inspection */}
      <div style={{ display: "flex", flexDirection: "column", gap: "16px" }}>
        {/* Tools Inspector */}
        <div style={{ background: "#0f172a", borderRadius: "12px", border: "1px solid #1e293b", padding: "16px" }}>
          <div style={{ display: "flex", alignItems: "center", gap: "8px", marginBottom: "10px" }}>
            <Wrench size={16} color="#f97316" />
            <h3 style={{ fontSize: "14px", margin: 0 }}>Registered Tools</h3>
          </div>
          <div style={{ display: "flex", flexDirection: "column", gap: "6px" }}>
            {tools.map((t) => (
              <div key={t} style={{ background: "#1e293b", padding: "8px 12px", borderRadius: "6px", fontSize: "12px", fontFamily: "monospace", color: "#fdba74" }}>
                🔧 {t}
              </div>
            ))}
          </div>
        </div>

        {/* Guardrails Inspector */}
        <div style={{ background: "#0f172a", borderRadius: "12px", border: "1px solid #1e293b", padding: "16px" }}>
          <div style={{ display: "flex", alignItems: "center", gap: "8px", marginBottom: "10px" }}>
            <ShieldCheck size={16} color="#10b981" />
            <h3 style={{ fontSize: "14px", margin: 0 }}>Active Guardrails</h3>
          </div>
          <div style={{ fontSize: "12px", color: "#64748b" }}>
            <div style={{ color: "#a7f3d0", padding: "4px 0" }}>✓ Output PII Sanitizer</div>
            <div style={{ color: "#a7f3d0", padding: "4px 0" }}>✓ Input Pattern Filter</div>
          </div>
        </div>

        {/* Memory Inspector */}
        <div style={{ flex: 1, background: "#0f172a", borderRadius: "12px", border: "1px solid #1e293b", padding: "16px", display: "flex", flexDirection: "column" }}>
          <div style={{ display: "flex", alignItems: "center", gap: "8px", marginBottom: "10px" }}>
            <History size={16} color="#a855f7" />
            <h3 style={{ fontSize: "14px", margin: 0 }}>Memory Buffer</h3>
          </div>
          <div style={{ flex: 1, overflowY: "auto", fontSize: "11px", fontFamily: "monospace", color: "#cbd5e1" }}>
            {memoryHistory.map((m, idx) => (
              <div key={idx} style={{ padding: "4px 0", borderBottom: "1px dashed #334155" }}>
                <strong>[{m.role}]:</strong> {m.content.slice(0, 45)}...
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
