import React, { useMemo } from "react";
import {
  ReactFlow,
  Background,
  Controls,
  Node,
  Edge,
  MarkerType,
} from "@xyflow/react";
import "@xyflow/react/dist/style.css";

export interface TraceStepNode {
  id: string;
  type: "userInput" | "modelCall" | "toolExecution" | "handoff" | "finalOutput";
  label: string;
  subText?: string;
  durationMs?: number;
  tokens?: number;
}

interface TraceViewerProps {
  traceSteps: TraceStepNode[];
}

const customNodeStyles: Record<TraceStepNode["type"], React.CSSProperties> = {
  userInput: {
    background: "#1e293b",
    border: "2px solid #3b82f6",
    color: "#93c5fd",
    borderRadius: "12px",
    padding: "12px 18px",
    fontWeight: 600,
    fontSize: "14px",
    minWidth: "180px",
  },
  modelCall: {
    background: "#1e1b4b",
    border: "2px solid #6366f1",
    color: "#c7d2fe",
    borderRadius: "12px",
    padding: "12px 18px",
    fontWeight: 600,
    fontSize: "14px",
    minWidth: "180px",
  },
  toolExecution: {
    background: "#1c1917",
    border: "2px solid #f97316",
    color: "#ffedd5",
    borderRadius: "12px",
    padding: "12px 18px",
    fontWeight: 600,
    fontSize: "14px",
    minWidth: "180px",
  },
  handoff: {
    background: "#310e3d",
    border: "2px solid #a855f7",
    color: "#f3e8ff",
    borderRadius: "12px",
    padding: "12px 18px",
    fontWeight: 600,
    fontSize: "14px",
    minWidth: "180px",
  },
  finalOutput: {
    background: "#064e3b",
    border: "2px solid #10b981",
    color: "#a7f3d0",
    borderRadius: "12px",
    padding: "12px 18px",
    fontWeight: 600,
    fontSize: "14px",
    minWidth: "180px",
  },
};

export const TraceViewer: React.FC<TraceViewerProps> = ({ traceSteps }) => {
  const { nodes, edges } = useMemo(() => {
    const n: Node[] = [];
    const e: Edge[] = [];

    const defaultSteps: TraceStepNode[] = traceSteps.length > 0 ? traceSteps : [
      { id: "1", type: "userInput", label: "User Input", subText: "'What's the weather in Tokyo?'" },
      { id: "2", type: "modelCall", label: "Model Call: gpt-4o", subText: "Latency: 240ms | Tokens: 42", durationMs: 240, tokens: 42 },
      { id: "3", type: "toolExecution", label: "Tool Execution", subText: "get_weather({ city: 'Tokyo' })", durationMs: 180 },
      { id: "4", type: "handoff", label: "Agent Handoff", subText: "TriageAgent -> WeatherAgent" },
      { id: "5", type: "finalOutput", label: "Final Output", subText: "'The weather in Tokyo is 22°C and clear.'" },
    ];

    let yOffset = 40;
    defaultSteps.forEach((step, idx) => {
      n.push({
        id: step.id,
        position: { x: 250, y: yOffset },
        data: {
          label: (
            <div style={{ display: "flex", flexDirection: "column", gap: "4px" }}>
              <span style={{ fontSize: "14px" }}>{step.label}</span>
              {step.subText && (
                <span style={{ fontSize: "11px", opacity: 0.8, fontFamily: "monospace" }}>
                  {step.subText}
                </span>
              )}
            </div>
          ),
        },
        style: customNodeStyles[step.type],
      });

      if (idx > 0) {
        const prevId = defaultSteps[idx - 1]!.id;
        e.push({
          id: `e-${prevId}-${step.id}`,
          source: prevId,
          target: step.id,
          animated: true,
          style: { stroke: "#64748b", strokeWidth: 2 },
          markerEnd: { type: MarkerType.ArrowClosed, color: "#64748b" },
        });
      }

      yOffset += 110;
    });

    return { nodes: n, edges: e };
  }, [traceSteps]);

  return (
    <div style={{ width: "100%", height: "100%", background: "#090d16", borderRadius: "12px", border: "1px solid #1e293b", overflow: "hidden" }}>
      <ReactFlow nodes={nodes} edges={edges} fitView>
        <Background color="#334155" gap={20} size={1} />
        <Controls style={{ background: "#1e293b", borderColor: "#334155", color: "#f8fafc" }} />
      </ReactFlow>
    </div>
  );
};
