import * as fs from "node:fs";
import * as path from "node:path";

export interface InitOptions {
  projectName?: string;
  targetDir?: string;
  provider?: "openai" | "claude" | "gemini" | "groq" | "openrouter";
}

export function initProject(options: InitOptions = {}): void {
  const name = options.projectName || "my-nekora-agent";
  const targetDir = options.targetDir ? path.resolve(options.targetDir) : path.join(process.cwd(), name);

  console.log(`\n🐾 Initializing new Nekora AI Agent project: ${name}...`);

  if (!fs.existsSync(targetDir)) {
    fs.mkdirSync(targetDir, { recursive: true });
  }

  // 1. Write package.json
  const pkgJson = {
    name,
    version: "1.0.0",
    type: "module",
    scripts: {
      dev: "tsx src/index.ts",
      build: "tsc",
    },
    dependencies: {
      "@nekora-ai/core": "^1.0.0",
      zod: "^3.23.8",
    },
    devDependencies: {
      "@types/node": "^24.0.0",
      tsx: "^4.19.0",
      typescript: "^5.9.0",
    },
  };
  fs.writeFileSync(path.join(targetDir, "package.json"), JSON.stringify(pkgJson, null, 2));

  // 2. Write tsconfig.json
  const tsConfig = {
    compilerOptions: {
      target: "ES2022",
      module: "NodeNext",
      moduleResolution: "NodeNext",
      strict: true,
      skipLibCheck: true,
    },
    include: ["src/**/*"],
  };
  fs.writeFileSync(path.join(targetDir, "tsconfig.json"), JSON.stringify(tsConfig, null, 2));

  // 3. Write .env.example
  const envContent = `OPENAI_API_KEY=your_openai_api_key_here
ANTHROPIC_API_KEY=your_anthropic_api_key_here
GEMINI_API_KEY=your_gemini_api_key_here
`;
  fs.writeFileSync(path.join(targetDir, ".env.example"), envContent);

  // 4. Create src/index.ts scaffold
  const srcDir = path.join(targetDir, "src");
  fs.mkdirSync(srcDir, { recursive: true });

  const starterCode = `import {
  Agent,
  tool,
  OpenAIProvider,
  InMemoryAdapter,
} from "@nekora-ai/core";
import { z } from "zod";

// 1. Define custom tools
const weatherTool = tool({
  name: "get_weather",
  description: "Get current weather for a city",
  schema: z.object({
    city: z.string().describe("City name"),
  }),
  execute: async ({ city }) => {
    return { city, temperature: "22°C", condition: "Sunny" };
  },
});

// 2. Instantiate Model & Agent
const model = new OpenAIProvider({ model: "gpt-4o-mini" });
const memory = new InMemoryAdapter();

const agent = new Agent({
  name: "Assistant Agent",
  instructions: "You are a helpful AI assistant with access to tools.",
  model,
  tools: [weatherTool],
  memory,
});

async function main() {
  console.log("🐾 Running Nekora AI Agent...");
  const result = await agent.run("What's the weather in Tokyo?");
  console.log("Response:", result.output);
}

main().catch(console.error);
`;
  fs.writeFileSync(path.join(targetDir, "src", "index.ts"), starterCode);

  console.log(`\n✨ Project created at ${targetDir}`);
  console.log(`\nNext steps:`);
  console.log(`  cd ${name}`);
  console.log(`  npm install (or pnpm install)`);
  console.log(`  npm run dev\n`);
}
